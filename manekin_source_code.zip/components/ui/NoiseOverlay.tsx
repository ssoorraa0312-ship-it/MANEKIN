"use client";

import styles from './NoiseOverlay.module.css';

export default function NoiseOverlay() {
    return <div className={styles.noise} />;
}
